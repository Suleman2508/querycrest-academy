/* SQLLAB v15 interface-only navigation helpers; never changes grading, progress, or database state. */
(()=>{'use strict';
 const $=s=>document.querySelector(s);
 function to(target,focus=false){const node=$(target);if(!node)return;node.scrollIntoView({behavior:'smooth',block:'start'});if(focus){try{node.focus({preventScroll:true})}catch{node.focus()}}}
 $('#v15-jump-to-editor')?.addEventListener('click',()=>to('#sql-editor',true));
 $$('[data-jump]').forEach(btn=>btn.addEventListener('click',()=>{
  const dest={concept:'#classroom-first-guide',example:'#guide-worked-code',practice:'#question-prompt',feedback:'#result-area'}[btn.dataset.jump];
  if(btn.dataset.jump==='feedback'&&!$('#result-area')?.textContent.trim()){to('#sql-editor',true);return}
  to(dest,btn.dataset.jump==='practice');
 }));
 function openTopics(){const s=$('#sidebar'),sh=$('#sidebar-shade');
  if(!s)return;
  if(window.matchMedia('(max-width:1120px)').matches){s.classList.add('open');sh?.classList.add('open');$('#v15-topic-filter')?.focus()}
  else{to('#topic-nav');$('#v15-topic-filter')?.focus()}}
 $('#v15-browse-topics')?.addEventListener('click',openTopics);
 const topicSearch=$('#v15-topic-filter'),topicNav=$('#topic-nav');
 function filterTopics(){if(!topicSearch||!topicNav)return;const q=topicSearch.value.trim().toLocaleLowerCase();
  topicNav.querySelectorAll('button.topic-link').forEach(btn=>{btn.hidden=!!q&&!btn.textContent.toLocaleLowerCase().includes(q)})}
 topicSearch?.addEventListener('input',filterTopics);
 if(topicNav&&window.MutationObserver)new MutationObserver(filterTopics).observe(topicNav,{childList:true});
 // Preserve a visible indication of the current top-level route.
 function refreshActive(){const home=document.body.classList.contains('home-mode');
  $$('.v15-bottom-tabs button').forEach(el=>el.classList.toggle('is-active',el.dataset.go===(home?'home':'learn')))}
 $$('.v15-bottom-tabs button').forEach(btn=>btn.addEventListener('click',()=>setTimeout(refreshActive,20)));
 refreshActive();
 document.addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();
    if(document.body.classList.contains('home-mode'))$('#scene-search')?.focus();else {openTopics();topicSearch?.focus()}}
 });
 function $$(s){return Array.from(document.querySelectorAll(s))}
})();
