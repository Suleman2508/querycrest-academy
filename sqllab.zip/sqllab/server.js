/* Local & deploy-ready zero-dependency Node.js 22.13+ server with real SQLite. */
'use strict';
const http=require('node:http'), fs=require('node:fs'), path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const C=require('./content.js');
const E=require('./engine.js');
// Tutor is now browser-only, rule-based, free: no API service.
const Lab=require('./playground.js');
const host=process.env.HOST||'127.0.0.1', port=Number(process.env.PORT)||3032;
const tutorCounters=new Map();
function limited(req){const ip=req.socket.remoteAddress||'local',now=Date.now();let c=tutorCounters.get(ip);if(!c||now-c.start>60000)c={start:now,count:0};c.count++;tutorCounters.set(ip,c);if(tutorCounters.size>2000){for(const [key,v] of tutorCounters){if(now-v.start>60000)tutorCounters.delete(key)}}return c.count>12;}
function createSession(){
  const db=new DatabaseSync(':memory:');db.exec(C.seed);
  return {
    execute(sql){db.exec(sql);},
    read(sql){const stmt=db.prepare(sql);const columns=stmt.columns().map(col=>col.name);const rows=stmt.all().map(r=>columns.map(c=>r[c]));return {columns,rows};},
    close(){db.close();}
  };
}
const publicFiles={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/app.css':'app.css','/scene.css':'scene.css','/scene-v8.css':'scene-v8.css','/scene-v9.css':'scene-v9.css','/scene-v10.css':'scene-v10.css','/premium-v11.css':'premium-v11.css','/premium-v11.js':'premium-v11.js','/minimal-v12.css':'minimal-v12.css','/minimal-v13.css':'minimal-v13.css','/classroom-v14.css':'classroom-v14.css','/layout-v15.css':'layout-v15.css','/theme-v16.css':'theme-v16.css','/atelier-v17.css':'atelier-v17.css','/bloom-tree.css':'bloom-tree.css','/classroom-glass-v17_5.css':'classroom-glass-v17_5.css','/layout-v15.js':'layout-v15.js','/classroom-guide.js':'classroom-guide.js','/tree-silhouette.svg':'tree-silhouette.svg','/scene.js':'scene.js','/content.js':'content.js','/engine.js':'engine.js','/preview.js':'preview.js','/tutor-client.js':'tutor-client.js','/lab-client.js':'lab-client.js'};
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webp':'image/webp','.svg':'image/svg+xml'};
function response(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
function readBody(req,res,callback){let body='',tooLarge=false;
 req.on('data',chunk=>{body+=chunk;if(body.length>55000&&!tooLarge){tooLarge=true;response(res,413,{message:'Request too large'});req.destroy();}});
 req.on('end',()=>{if(tooLarge)return;try{callback(JSON.parse(body));}catch(err){response(res,400,{message:String(err.message||err)})}});
}
const server=http.createServer((req,res)=>{
 if(req.method==='GET'&&req.url==='/api/health')return response(res,200,{ok:true,engine:'SQLite',aiEnabled:false,version:'v17.5-glass-classroom'});
 if(req.method==='POST'&&req.url==='/api/check'){
  return readBody(req,res,data=>{const exercise=E.exerciseById(data.exerciseId);
   if(!exercise)return response(res,404,{message:'Exercise not found'});
   response(res,200,E.runAssessment(exercise,data.sql,createSession));});
 }
 if(req.method==='POST'&&req.url==='/api/playground'){
  return readBody(req,res,data=>{try{response(res,200,Lab.runLab(data.tables,data.sql));}
   catch(err){response(res,200,{ok:false,message:String(err.message||err)})}});
 }
 if(req.method==='GET'){
  const filename=publicFiles[decodeURI(req.url.split('?')[0])];if(!filename){res.writeHead(404);res.end('Not found');return;}
  const full=path.join(__dirname,filename);fs.readFile(full,(err,bytes)=>{if(err){res.writeHead(404);res.end('Missing');return;}res.writeHead(200,{'Content-Type':types[path.extname(filename)],'Cache-Control':'no-store'});res.end(bytes);});return;
 }
 res.writeHead(405);res.end('Method not allowed');
});
server.listen(port,host,()=>console.log(`SQL Practice Hub ready: http://localhost:${port} (SQLite engine)`));
