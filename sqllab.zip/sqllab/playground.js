/* Isolated custom-dataset playground with strictly validated schemas and bounded workloads. */
'use strict';
const {DatabaseSync}=require('node:sqlite');
const MAX_TABLES=8, MAX_ROWS=120, MAX_COLUMNS=15;
const nameValid=s=>/^[a-zA-Z_][a-zA-Z_0-9]{0,39}$/.test(s);
function buildSession(tables){
 if(!Array.isArray(tables)||tables.length>MAX_TABLES)throw Error('Maximum 8 custom tables allowed');
 const db=new DatabaseSync(':memory:'); db.exec('PRAGMA query_only = OFF;');
 const names=new Set();
 try{
 for(const t of tables){
  if(!nameValid(t.name)||names.has(t.name.toLowerCase()))throw Error('Table name must be unique, letters/numbers/underscores only.');
  names.add(t.name.toLowerCase());
  if(!Array.isArray(t.columns)||t.columns.length<1||t.columns.length>MAX_COLUMNS)throw Error('Each table needs 1 to 15 columns');
  const colNames=new Set();
  const defs=t.columns.map(c=>{
   if(!nameValid(c.name)||colNames.has(c.name.toLowerCase()))throw Error('Invalid / duplicate column name');
   colNames.add(c.name.toLowerCase());
   if(!['INTEGER','TEXT','REAL','NUMERIC'].includes(c.type))throw Error('Data type must be INTEGER, TEXT, REAL or NUMERIC');
   return '"'+c.name+'" '+c.type;
  });
  db.exec('CREATE TABLE "'+t.name+'" ('+defs.join(',')+')');
  if(!Array.isArray(t.rows)||t.rows.length>MAX_ROWS)throw Error('Maximum 120 sample rows per table');
  const stmt=db.prepare('INSERT INTO "'+t.name+'" VALUES ('+t.columns.map(()=>'?').join(',')+')');
  for(const row of t.rows){if(!Array.isArray(row)||row.length!==t.columns.length)throw Error('Data rows must match the column count');
   stmt.run(...row.map((v,i)=>{
    if(v===null||v===undefined||v==='')return null;
    if(t.columns[i].type==='INTEGER'||t.columns[i].type==='REAL'||t.columns[i].type==='NUMERIC'){
     const num=Number(v);if(!Number.isFinite(num))throw Error('Numeric field has invalid value');return num;
    }
    return String(v).slice(0,250);
   }));
  }
 }
 return db;
 }catch(err){db.close();throw err}
}
const stripQuoted=s=>s.replace(/'(?:''|[^'])*'|"(?:""|[^"])*"|`(?:``|[^`])*`|\[(?:[^\]])*\]/g,'TEXT').replace(/--[^\n]*/g,'').replace(/\/\*[\s\S]*?\*\//g,'');
function validateSelect(input){const sql=String(input||'').trim().replace(/;+\s*$/,'');
 if(sql.length>3500)throw Error('Limit query to 3500 characters');
 if(!/^\s*(SELECT|WITH|EXPLAIN)\b/i.test(sql))throw Error('Custom lab query editor is read-only: use SELECT, WITH or EXPLAIN. Build tables using My Tables form.');
 const noQuotes=stripQuoted(sql);
 if(/;/.test(noQuotes))throw Error('One statement only.');
 if(/\b(ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|CREATE|DROP|INSERT|UPDATE|DELETE|ALTER|REPLACE)\b/i.test(noQuotes))throw Error('Only SELECT / WITH / EXPLAIN statements allowed in My Tables lab.');
 if(!sql)throw Error('Write your SQL first');
 return sql;
}
function runLab(tables,query){const sql=validateSelect(query),db=buildSession(tables);try{
 db.exec('PRAGMA query_only = ON');
 const stmt=db.prepare(sql);const columns=stmt.columns().map(c=>c.name);const rows=stmt.all().map(r=>columns.map(c=>r[c]));
 return {ok:true,columns,rows:rows.slice(0,150),totalRows:rows.length};
 }finally{db.close();}}
module.exports={buildSession,runLab,validateSelect};
