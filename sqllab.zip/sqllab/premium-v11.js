/* SQLLAB v11: non-invasive enhancement layer. Never reveals SQL solutions. */
(()=>{'use strict';
 const $=s=>document.querySelector(s);
 const NOTES_KEY='sqllab-topic-notes-v11',FOCUS_KEY='sqllab-study-focus-v11',PROGRESS_KEY='sqllab-progress-v2';
 const safeRead=()=>{try{let j=JSON.parse(localStorage.getItem(NOTES_KEY)||'{}');return j&&typeof j==='object'&&!Array.isArray(j)?j:{}}catch{return {}}};
 let notes=safeRead(),lastTopic='',saveTimer=null;
 const viewTopic=()=>{try{return JSON.parse(localStorage.getItem(PROGRESS_KEY)||'{}').position?.topic||'tables'}catch{return 'tables'}};
 const notesEditor=$('#study-notes-editor'),noteCount=$('#study-notes-count'),noteStatus=$('#study-notes-status'),noteSummary=$('#study-notes-summary');
 function updateNoteUI(){if(!notesEditor)return;const topic=viewTopic();if(topic===lastTopic)return;
  lastTopic=topic;notesEditor.value=notes[topic]||'';if(noteCount)noteCount.textContent=notesEditor.value.length+' / 10,000';if(noteStatus)noteStatus.textContent='Saved for this topic';if(noteSummary)noteSummary.textContent=notes[topic]?.trim()?'✓ Notes saved · Private':'Private · Saved in this browser';}
 function saveNote(){if(!notesEditor)return;const topic=lastTopic||viewTopic();notes[topic]=notesEditor.value;try{localStorage.setItem(NOTES_KEY,JSON.stringify(notes));if(noteStatus)noteStatus.textContent='✓ Saved automatically';if(noteSummary)noteSummary.textContent=notes[topic]?.trim()?'✓ Notes saved · Private':'Private · Saved in this browser';}catch{if(noteStatus)noteStatus.textContent='⚠ Storage full — take a backup';}}
 notesEditor?.addEventListener('input',()=>{if(noteCount)noteCount.textContent=notesEditor.value.length+' / 10,000';if(noteStatus)noteStatus.textContent='Saving…';clearTimeout(saveTimer);saveTimer=setTimeout(saveNote,350)});
 notesEditor?.addEventListener('blur',()=>{clearTimeout(saveTimer);saveNote()});
 function setFocus(on){document.body.classList.toggle('study-focus',on);const btn=$('#study-focus-toggle');if(btn){btn.setAttribute('aria-pressed',String(on));btn.textContent=on?'✓ Exit Focus':'◈ Focus Mode';btn.title=on?'Return to full classroom':'Focus on your current SQL lesson (Ctrl+Shift+F)'}const quick=$('#quick-focus');if(quick)quick.textContent=on?'↗ Exit Focus':'◈ Focus';try{localStorage.setItem(FOCUS_KEY,on?'on':'off')}catch{}}
 $('#study-focus-toggle')?.addEventListener('click',()=>{if(document.body.classList.contains('home-mode')){document.querySelector('[data-go="learn"]')?.click();}setFocus(!document.body.classList.contains('study-focus'))});
 $('#quick-focus')?.addEventListener('click',()=>{setFocus(!document.body.classList.contains('study-focus'));$('#study-quickbar')?.scrollIntoView({block:'start'})});
 $('#note-jump')?.addEventListener('click',()=>{const notes=$('#study-notes');if(!notes)return;notes.open=true;notes.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>notesEditor?.focus(),250)});
 document.addEventListener('keydown',e=>{const tag=(e.target?.tagName||'').toLowerCase();if((e.ctrlKey||e.metaKey)&&e.shiftKey&&e.key.toLowerCase()==='f'){e.preventDefault();if(document.body.classList.contains('home-mode'))document.querySelector('[data-go="learn"]')?.click();setFocus(!document.body.classList.contains('study-focus'))}
 else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){/* v15 handles focus on topic search without switching the current lesson. */}
 else if(e.key==='Escape'&&document.body.classList.contains('study-focus')&&!['input','textarea'].includes(tag)){setFocus(false)}});
 const liveNotes=()=>{const topic=viewTopic();if(topic!==lastTopic){clearTimeout(saveTimer);if(lastTopic)saveNote();updateNoteUI()}};
 // Existing app writes progress to localStorage whenever the learner changes topics/exercises.
 window.addEventListener('storage',liveNotes);setInterval(liveNotes,450);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)saveNote()});
 setFocus(false);updateNoteUI();
})();
