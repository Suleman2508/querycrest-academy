/* SQL execution assessment. Actual user queries run in a disposable SQLite database. */
(function(root, factory){let lib=factory(); if(typeof module==='object'&&module.exports)module.exports=lib; if(root)root.SQL_HUB_ENGINE=lib;})(typeof window!=='undefined'?window:globalThis,function(){
  const exerciseById = id => SQL_HUB_CONTENT.topics.flatMap(t=>t.exercises).find(e=>e.id===id);
  function cleanSql(sql){return String(sql||'').trim().replace(/;+\s*$/, '').trim()}
  function stripQuoted(sql){return sql.replace(/'(?:''|[^'])*'|"(?:""|[^"])*"|`(?:``|[^`])*`|\[(?:[^\]])*\]/g,'STR').replace(/--[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g,'')}
  function validate(sql,e){
    if(!sql) return 'Query empty undi. Editor lo SQL rayi, taruvatha Check Query click cheyyi.';
    if(sql.length>5000) return 'Query too long (max 5000 characters).';
    const safelyStripped=stripQuoted(sql);
    if(safelyStripped.includes(';'))return 'Practice lo one SQL statement only. Multiple statements use cheyyakandi.';
    if(e.mode==='mutation'){
      if(!/^\s*(insert|update|delete|create|alter|drop)\b/i.test(sql))return 'Ee exercise lo INSERT / UPDATE / DELETE / CREATE / ALTER lanti data/schema query rayali.';
    }else if(!/^\s*(select|with|values)\b/i.test(sql))return 'Ee question SELECT query exercise. SELECT or WITH tho start cheyyi.';
    return null;
  }
  function normal(v){ if(v===null||v===undefined)return null; if(typeof v==='number')return Number(v.toPrecision(12)); if(typeof v==='bigint')return Number(v); return String(v); }
  function signature(row){return JSON.stringify(row.map(normal));}
  function standard(result){const rows=(result.rows||[]).map(r=>Array.isArray(r)?r:Object.values(r)); return {columns:result.columns||[],rows};}
  function compare(actual,expected,strictOrder){
    if(actual.columns.length!==expected.columns.length) return {equal:false,why:`Expected ${expected.columns.length} columns, but your query returned ${actual.columns.length}.`};
    if(actual.rows.length!==expected.rows.length) return {equal:false,why:`Expected ${expected.rows.length} rows, but your query returned ${actual.rows.length}.`};
    const a=actual.rows.map(signature),b=expected.rows.map(signature);
    if(!strictOrder){a.sort();b.sort();}
    const mismatch=a.findIndex((x,i)=>x!==b[i]);
    return mismatch===-1?{equal:true,why:''}:{equal:false,why:strictOrder?'Output values correct order lo levu. ORDER BY direction / LIMIT check cheyyi.':'Rows/values expected output tho match kaledu. Filters, columns, JOIN condition and aggregates check cheyyi.'};
  }
  function diagnose(sql,e,err,diff){
    if(err){
      const msg=String(err.message||err);
      if(/no such column/i.test(msg))return 'Column name spelling check cheyyi. Dataset table headers lo available columns choodu. SQL strings single quotes lo rayali.';
      if(/no such table/i.test(msg))return 'Table name correct ga unda check cheyyi. Dataset tables lo matching name choose cheyyi.';
      if(/syntax error|incomplete input|unrecognized token/i.test(msg))return 'SQL syntax lo mistake undi. SELECT columns FROM table WHERE condition; ane structure verify cheyyi. Commas, quotes, brackets check cheyyi.';
      if(/ambiguous column/i.test(msg))return 'JOIN lo same-name columns unnayi. c.id or o.id la table alias prefix use cheyyi.';
      if(/misuse of aggregate/i.test(msg))return 'COUNT/SUM/AVG ni WHERE lo direct ga use cheyalemu. GROUP BY taruvatha HAVING use cheyyi.';
      if(/no such function/i.test(msg))return 'Function name or SQL dialect check cheyyi. Practice engine SQLite; PostgreSQL syntax may differ.';
      return 'SQLite reported: '+msg;
    }
    const lower=sql.toLowerCase(), target=e.solution.toLowerCase();
    if(e.id.includes('like')){
      const userPattern=sql.match(/\blike\s*['"]([^'"]+)['"]/i)?.[1]||'';
      const expectedPattern=e.solution.match(/\blike\s*['"]([^'"]+)['"]/i)?.[1]||'';
      if(!lower.includes('like'))return "Ee topic LIKE. Name pattern match cheyyadaniki WHERE name LIKE 'S%' la rayi.";
      if(userPattern){
        if(!userPattern.includes('%')&&!userPattern.includes('_'))return "LIKE lo wildcard missing. 'S' only exact match chestundi, 'S%' starts-with, '%s' ends-with.";
        if(expectedPattern.endsWith('%')&&!expectedPattern.startsWith('%')&&userPattern.startsWith('%'))return "Starts with condition lo % right side lo undali. 'S%' starts with S, '%S' ends with S.";
        if(expectedPattern.startsWith('%')&&!expectedPattern.endsWith('%')&&userPattern.endsWith('%'))return "Ends with condition lo % left side lo undali. '%s' ends with s; 's%' starts with s.";
        if(expectedPattern.startsWith('%')&&expectedPattern.endsWith('%')&&!(userPattern.startsWith('%')&&userPattern.endsWith('%')))return "Contains word kosam pattern rendu sides % undali: '%phone%'.";
        if(expectedPattern.includes('_')&&userPattern.split('_').length!==expectedPattern.split('_').length)return 'Underscore (_) exactly ONE character; question lo word total length count cheyyi.';
      }
      return 'LIKE pattern, wildcard placement, selected columns and table check cheyyi. % = zero/more chars; _ = exactly one char.';
    }
    if(e.id.includes('group')||e.id.includes('having')){
      if(!/group\s+by/i.test(sql))return 'GROUP BY missing undochu. category/department-wise results kosam GROUP BY column use cheyyi.';
      if(e.id.includes('having')&&!/having/i.test(sql))return 'HAVING missing undochu. Aggregated COUNT/SUM/AVG meeda condition HAVING lo rayali.';
      return 'GROUP BY keys, COUNT(*) / SUM(column), HAVING condition verify cheyyi.';
    }
    if(e.id.includes('sort'))return 'ORDER BY ASC vs DESC, LIMIT number and columns check cheyyi.';
    if(e.id.includes('agg'))return 'COUNT(*) counts rows, SUM(column) totals values, AVG(column) averages. Correct function / column choose cheyyi.';
    if(e.id.includes('inner')||e.id.includes('left')||e.id.includes('complex'))return 'JOIN lo correct ON keys (customer.id = order.customer_id etc.) and INNER vs LEFT selection check cheyyi.';
    if(e.mode==='mutation')return 'Your statement executed, kani final table/schema expected result la ledu. WHERE condition, column names, values / index order verify cheyyi.';
    return diff?.why||'WHERE conditions, selected fields and SQL logic check cheyyi. Query syntax valid ayina expected answer different.';
  }
  function runAssessment(e,raw,createSession){
    const sql=cleanSql(raw); const problem=validate(sql,e);
    if(problem)return {ok:false,valid:false,headline:'Query needs correction',message:problem,explanation:e.why,hint:e.hint,queryOutput:null,expectedOutput:null};
    let actual,expected;try{
      const db=createSession();
      if(e.mode==='mutation')db.execute(sql,e.mode); actual=standard(db.read(e.mode==='mutation'?e.inspectSql:sql));
      db.close?.();
    }catch(err){
      const why=diagnose(sql,e,err,null);
      try {const db2=createSession(); if(e.mode==='mutation') db2.execute(e.solution,e.mode); expected=standard(db2.read(e.mode==='mutation'?e.inspectSql:e.solution)); db2.close?.();}catch(_ignored){}
      return {ok:false,valid:false,headline:'Syntax / execution error',message:why,rawError:String(err.message||err),explanation:e.why,hint:e.hint,queryOutput:null,expectedOutput:cap(expected)};
    }
    try{const ref=createSession();if(e.mode==='mutation')ref.execute(e.solution,e.mode);expected=standard(ref.read(e.mode==='mutation'?e.inspectSql:e.solution));ref.close?.();}catch(err){return {ok:false,valid:false,headline:'Reference question error',message:String(err.message||err)};}
    let match=compare(actual,expected,e.id.includes('sort'));
    // A matching output from one small sample is not proof of matching SQL logic.
    // Extra boundary records catch > vs >= and BETWEEN endpoint mistakes.
    let edgeCaseFailed=false;
    const boundarySeeds={
      'b-where-1':"INSERT INTO products VALUES(9001,'Edge Phone','Electronics',50000,1,'Boundary test');",
      'b-logic-1':"INSERT INTO products VALUES(9001,'Edge Phone','Electronics',50000,1,'Boundary test');",
      'b-filter-2':"INSERT INTO products VALUES(9001,'Low Edge','Accessories',1000,1,'Boundary test'); INSERT INTO products VALUES(9002,'High Edge','Accessories',5000,1,'Boundary test');"
    };
    if(match.equal&&boundarySeeds[e.id]&&e.mode!=='mutation'){
      try{
        const edgeUser=createSession(),edgeRef=createSession();
        edgeUser.execute(boundarySeeds[e.id]);edgeRef.execute(boundarySeeds[e.id]);
        const edgeActual=standard(edgeUser.read(sql)),edgeExpected=standard(edgeRef.read(e.solution));
        edgeUser.close?.();edgeRef.close?.();
        const edgeMatch=compare(edgeActual,edgeExpected,false);
        if(!edgeMatch.equal){actual=edgeActual;expected=edgeExpected;match=edgeMatch;edgeCaseFailed=true;}
      }catch(_boundaryError){/* Primary dataset result still applies if an extra test cannot run. */}
    }
    const feedback=match.equal?'Real SQLite lo query run ayyindi. Output expected result tho match ayyindi.':
      edgeCaseFailed?'Your SQL gives the right result on the first table, but fails when boundary values are added. English: Check whether the range includes the endpoint. Tenglish: >, >=, BETWEEN range limits careful ga check cheyyi.':diagnose(sql,e,null,match);
    return {ok:match.equal,valid:true,headline:match.equal?'Correct! Query passed.':edgeCaseFailed?'Almost right — boundary test failed':'Almost there — check your logic',message:feedback,explanation:e.why,hint:e.hint,queryOutput:cap(actual),expectedOutput:match.equal?null:cap(expected),difference:match.why};
  }
  function cap(result){if(!result)return null;return {columns:result.columns,rows:result.rows.slice(0,80),totalRows:result.rows.length};}
  return {exerciseById,runAssessment,cleanSql,stripQuoted};
});
