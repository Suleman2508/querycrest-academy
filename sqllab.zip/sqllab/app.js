/* SQLLAB — browser app, real SQLite query validation, persistent learning progress. */
(() => {
  'use strict';
  const C = window.SQL_HUB_CONTENT, E = window.SQL_HUB_ENGINE, P = window.SQL_HUB_PREVIEW;
  const topics = C.topics; const allExercises=topics.flatMap(t=>t.exercises);
  const KEY='sqllab-progress-v2', THEME='sqllab-theme-v1', WORKSPACE='sqllab-workspace-v1';
  const LESSON_LANGUAGE='sqllab-lesson-language-v14';
  // v12 defaults to white once; thereafter preserve every deliberate theme choice.
  try{if(!localStorage.getItem('sqllab-tree-v12-initialized')){localStorage.setItem(THEME,'light');localStorage.setItem('sqllab-tree-v12-initialized','yes');}}catch{}
  const safeJSON=(name,fallback)=>{try{const val=localStorage.getItem(name);return val?JSON.parse(val):fallback}catch{return fallback}};
  const saved=safeJSON(KEY,{});
  const findPosition=(previous)=>{
    const byId=new Map(allExercises.map((e,i)=>[e.id,i]));
    const fromIndex=index=>{
      const e=allExercises[index];if(!e)return null;
      const topic=topics.find(t=>t.exercises.some(x=>x.id===e.id));
      return topic?{level:topic.level,topic:topic.id,exercise:topic.exercises.findIndex(x=>x.id===e.id)}:null;
    };
    const pos=previous?.position;
    const legacyTopicQuestions={ddl:['b-ddl-1','b-ddl-2','b-ddl-3'],dml:['b-dml-1','b-dml-2','b-dml-3']};
    if(pos?.questionId&&byId.has(pos.questionId))return fromIndex(byId.get(pos.questionId));
    if(pos&&legacyTopicQuestions[pos.topic]&&Number.isInteger(pos.exercise)){
      const oldId=legacyTopicQuestions[pos.topic][pos.exercise]; if(oldId&&byId.has(oldId))return fromIndex(byId.get(oldId));
    }
    if(pos&&topics.some(t=>t.id===pos.topic&&t.level===pos.level&&Number.isInteger(pos.exercise)&&pos.exercise>=0&&pos.exercise<t.exercises.length))return pos;
    // Migrate the earlier SQLLAB version, which saved passes/drafts but not the active question.
    const drafted=Object.keys(previous?.drafts||{}).filter(id=>byId.has(id)&&String(previous.drafts[id]||'').trim());
    if(drafted.length)return fromIndex(byId.get(drafted[0]));
    const attempted=Object.keys(previous?.attempts||{}).filter(id=>byId.has(id));
    if(attempted.length){const id=attempted.at(-1);return fromIndex(byId.get(id));}
    const passes=Object.keys(previous?.passed||{}).filter(id=>byId.has(id)&&previous.passed[id]);
    if(passes.length){const idx=byId.get(passes.at(-1));
      for(let i=idx+1;i<allExercises.length;i++)if(!previous.passed[allExercises[i].id])return fromIndex(i);
      return fromIndex(idx);
    }
    return {level:'basic',topic:'tables',exercise:0};
  };
  const position=findPosition(saved);
  const state={level:position.level,topic:position.topic,exercise:position.exercise,passed:saved.passed||{},attempts:saved.attempts||{},drafts:saved.drafts||{},theme:localStorage.getItem(THEME)||'light',fullTable:false,activeTable:null,result:null,hint:false,checking:false,engine:'initializing',sql:null,exampleExpanded:{}};
  const $=sel=>document.querySelector(sel);
  const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const qfn=(id)=>document.getElementById(id);
  const currentPosition=()=>({level:state.level,topic:state.topic,exercise:state.exercise,questionId:currentExercise()?.id});
  function saveStatus(message,failed=false){const el=qfn('save-status');if(el){el.textContent=message;el.classList.toggle('error',failed)}const headline=qfn('autosave-headline');if(headline)headline.textContent=failed?'Auto Save failed — download a backup':'Auto Save is ON ✓'}
  function stored(){try{
    const data={passed:state.passed,attempts:state.attempts,drafts:state.drafts,position:currentPosition(),savedAt:new Date().toISOString()};
    localStorage.setItem(KEY,JSON.stringify(data));
    // Detect browsers that silently disable localStorage on file: or in private browsing.
    if(!localStorage.getItem(KEY))throw new Error('Browser storage unavailable');
    saveStatus('✓ Saved just now · Lesson, question number, query drafts and completed tasks are safe in this browser.');
    return true;
  }catch(err){console.warn('Progress could not be stored',err);saveStatus('⚠ Browser cannot save progress. Try normal Chrome mode or download a backup.',true);return false;}}
  function setupBackup(){
    const jump=qfn('jump-resume');jump.onclick=()=>{window.SQLLAB_LAB?.setMode('guided');qfn('question-prompt')?.scrollIntoView({behavior:'smooth',block:'start'});};
    qfn('export-progress').onclick=()=>{
      stored();
      let coach=[];try{coach=JSON.parse(sessionStorage.getItem('sqllab-free-coach-chat-v1')||'[]')}catch{}
      const backup={format:'sqllab-learning-backup-v1',createdAt:new Date().toISOString(),progress:safeJSON(KEY,{}),customTables:safeJSON('sqllab-own-tables-v1',[]),customQuery:localStorage.getItem('sqllab-own-query-v1')||'',workspace:localStorage.getItem(WORKSPACE)||'guided',theme:state.theme,topicNotes:safeJSON('sqllab-topic-notes-v11',{}),lessonLanguage:localStorage.getItem(LESSON_LANGUAGE)||'both',coachChat:Array.isArray(coach)?coach:[]};
      const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);
      const link=document.createElement('a');link.href=url;link.download='SQLLAB_Backup_'+new Date().toISOString().slice(0,10)+'.json';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
      saveStatus('✓ Backup downloaded. Keep this JSON file safe; Restore Backup can recover it on another browser or device.');
    };
    const file=qfn('progress-file');qfn('import-progress').onclick=()=>file.click();
    file.addEventListener('change',async()=>{const chosen=file.files?.[0];if(!chosen)return;
      try{
        if(chosen.size>2_000_000)throw new Error('Backup file too large (2 MB max).');
        const backup=JSON.parse(await chosen.text());
        if(backup.format!=='sqllab-learning-backup-v1'&&!('passed' in backup&&'drafts' in backup))throw new Error('Please select a SQLLAB backup JSON file.');
        const incoming=backup.progress||backup;
        if(!incoming||typeof incoming!=='object'||!incoming.passed||typeof incoming.passed!=='object'||!incoming.drafts||typeof incoming.drafts!=='object')throw new Error('Incomplete progress data.');
        if(!confirm('Restore your SQLLAB backup? Existing passed answers will be kept; imported drafts/last lesson will be restored.'))return;
        const current=safeJSON(KEY,{});
        const merged={passed:{...(current.passed||{}),...incoming.passed},attempts:{...(current.attempts||{}),...(incoming.attempts||{})},drafts:{...(current.drafts||{}),...incoming.drafts},position:(()=>{const next=findPosition(incoming),ch=topics.find(t=>t.id===next.topic);return {...next,questionId:ch?.exercises[next.exercise]?.id}})(),savedAt:new Date().toISOString()};
        localStorage.setItem(KEY,JSON.stringify(merged));
        if(Array.isArray(backup.customTables))localStorage.setItem('sqllab-own-tables-v1',JSON.stringify(backup.customTables));
        if(typeof backup.customQuery==='string')localStorage.setItem('sqllab-own-query-v1',backup.customQuery);
        if(backup.workspace==='custom'||backup.workspace==='guided')localStorage.setItem(WORKSPACE,backup.workspace);
        if(['english','tenglish','both'].includes(backup.lessonLanguage))localStorage.setItem(LESSON_LANGUAGE,backup.lessonLanguage);
        if(backup.theme==='dark'||backup.theme==='light')localStorage.setItem(THEME,backup.theme);
        if(backup.topicNotes && typeof backup.topicNotes==='object' && !Array.isArray(backup.topicNotes)){const oldNotes=safeJSON('sqllab-topic-notes-v11',{});localStorage.setItem('sqllab-topic-notes-v11',JSON.stringify({...oldNotes,...backup.topicNotes}));}
        if(Array.isArray(backup.coachChat))try{sessionStorage.setItem('sqllab-free-coach-chat-v1',JSON.stringify(backup.coachChat.slice(-24)))}catch{}
        location.reload();
      }catch(err){saveStatus('⚠ Restore failed: '+err.message,true)}finally{file.value='';}
    });
  }
  const currentTopic=()=>topics.find(t=>t.id===state.topic)||topics[0];
  const currentExercise=()=>currentTopic().exercises[state.exercise];
  const counts=t=>t.exercises.filter(e=>state.passed[e.id]).length;
  const levelTotal=l=>topics.filter(t=>t.level===l).reduce((a,t)=>a+t.exercises.length,0);
  const levelDone=l=>topics.filter(t=>t.level===l).reduce((a,t)=>a+counts(t),0);
  const totalDone=()=>allExercises.filter(e=>state.passed[e.id]).length;
  const icons={tables:'⌗',constraints:'🔑',insert:'＋',logic:'∧',updates:'✎',deletes:'×',alter:'↺',relationships:'⋈',selfjoin:'↔',crossjoin:'×',nulltools:'◇',recursive:'↻',views:'◫',select:'▤',where:'≠',like:'%',filters:'◇',sort:'↓',aggregates:'Σ',groupintro:'▦',dml:'✎',ddl:'⌗',having:'≡',innerjoin:'⋈',leftjoin:'⊂',subquery:'⧉',case:'?',functions:'ƒ',union:'∪',cte:'WITH',window:'#',analytics:'∑',exists:'∃',complex:'⋈',perf:'⚡',production:'◎'};
  function setTheme(){document.body.classList.toggle('dark',state.theme==='dark');document.body.classList.toggle('light',state.theme==='light');qfn('theme-toggle').textContent=state.theme==='dark'?'☀':'☾';qfn('theme-toggle').title=state.theme==='dark'?'Switch to light mode':'Switch to dark mode';qfn('theme-toggle').setAttribute('aria-label',qfn('theme-toggle').title);const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute('content',state.theme==='dark'?'#080808':'#ffffff');}
  function changeLevel(level){state.level=level;const t=topics.find(t=>t.level===level);state.topic=t?.id||'tables';state.exercise=0;state.result=null;state.hint=false;state.fullTable=false;state.activeTable=null;renderAll();stored();scrollToLesson();closeMenu();}
  function changeTopic(id){const t=topics.find(t=>t.id===id);if(!t)return;state.level=t.level;state.topic=t.id;state.exercise=0;state.result=null;state.hint=false;state.fullTable=false;state.activeTable=null;renderAll();stored();scrollToLesson();closeMenu();}
  function changeExercise(n){let idx=n;if(n<0){const levelTopics=topics.filter(t=>t.level===state.level), pos=levelTopics.findIndex(t=>t.id===state.topic);if(pos>0)return changeTopicLast(levelTopics[pos-1].id);return;}if(n>=currentTopic().exercises.length){const levelTopics=topics.filter(t=>t.level===state.level),pos=levelTopics.findIndex(t=>t.id===state.topic);if(pos<levelTopics.length-1)return changeTopic(levelTopics[pos+1].id);return;}state.exercise=idx;state.result=null;state.hint=false;state.activeTable=null;state.fullTable=false;renderAll();stored();scrollToLesson();}
  function changeTopicLast(id){changeTopic(id);state.exercise=currentTopic().exercises.length-1;renderAll();stored();}
  function scrollToLesson(){const el=$('.lesson-bar');if(el)el.scrollIntoView({behavior:'smooth',block:'start'});}
  function closeMenu(){qfn('sidebar').classList.remove('open');qfn('sidebar-shade').classList.remove('open')}
  function renderNav(){
    qfn('level-nav').innerHTML=C.levels.map((l,i)=>`<button class="nav-level ${l.id===state.level?'active':''}" data-level="${l.id}"><span class="level-circle">${['01','02','03'][i]}</span><span class="level-detail"><b>${l.title} SQL</b><small>${escapeHTML(l.subtitle)}</small></span><span class="level-count">${levelDone(l.id)}/${levelTotal(l.id)}</span></button>`).join('');
    const subset=topics.filter(t=>t.level===state.level);qfn('topic-count').textContent=subset.length+' modules';
    qfn('topic-nav').innerHTML=subset.map((t,i)=>`<button data-topic="${t.id}" class="topic-link ${t.id===state.topic?'active':''}"><span class="topic-index">${String(i+1).padStart(2,'0')}</span><span class="topic-name">${escapeHTML(t.title)}</span>${counts(t)===t.exercises.length?'<span class="done-small">✓</span>':`<span class="topic-fraction">${counts(t)}/${t.exercises.length}</span>`}</button>`).join('');
    qfn('level-nav').querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>changeLevel(b.dataset.level));
    qfn('topic-nav').querySelectorAll('[data-topic]').forEach(b=>b.onclick=()=>changeTopic(b.dataset.topic));
    const done=totalDone(),pct=Math.round(done/allExercises.length*100);
    qfn('sidebar-progress').textContent=pct+'%';qfn('sidebar-progressbar').style.width=pct+'%';qfn('sidebar-count').textContent=done+' of '+allExercises.length+' queries passed';
    // The Atelier dashboard uses new progress cards; old hero nodes no longer exist.
    const legacyHeroCount=qfn('hero-count'),legacyHeroRing=qfn('hero-ring');
    if(legacyHeroCount)legacyHeroCount.textContent=done;
    if(legacyHeroRing)legacyHeroRing.style.background=`conic-gradient(#beadff 0deg, #72e1d2 ${pct*3.6}deg, #ffffff22 ${pct*3.6}deg)`;
    qfn('track-cards').innerHTML=C.levels.map((l,i)=>`<button class="track-card ${l.id} ${l.id===state.level?'active':''}" data-level="${l.id}" aria-label="Open ${escapeHTML(l.title)} level"><div class="track-card-top"><span class="track-icon">${['◈','⌘','✦'][i]}</span><span class="track-fraction">LEVEL ${String(i+1).padStart(2,'0')}</span></div><h3>${l.title} SQL <span class="card-arrow">↗</span></h3><p>${escapeHTML(l.description)}</p><div class="track-card-footer"><span>${levelDone(l.id)} of ${levelTotal(l.id)} solved</span><span>${Math.round(levelDone(l.id)/levelTotal(l.id)*100)}%</span></div><div class="track-meter"><span style="width:${Math.round(levelDone(l.id)/levelTotal(l.id)*100)}%"></span></div></button>`).join('');
    qfn('track-cards').querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>changeLevel(b.dataset.level));
  }
  function renderClassroomGuide(){
    const topic=currentTopic();const info=window.SQLLAB_CLASSROOM?.knowledge?.[topic.id];if(!info)return;
    qfn('guide-english-text').textContent=info.english;
    qfn('guide-tenglish-text').textContent=info.tenglish;
    qfn('guide-english-when').textContent=info.whyEnglish;
    qfn('guide-tenglish-when').textContent=info.whyTenglish;
    qfn('guide-worked-code').textContent=info.example;
    qfn('guide-breakdown').textContent=info.breakdown;
    const choice=['both','english','tenglish'].includes(localStorage.getItem(LESSON_LANGUAGE))?localStorage.getItem(LESSON_LANGUAGE):'both';
    qfn('guide-english').hidden=choice==='tenglish';
    qfn('guide-tenglish').hidden=choice==='english';
    qfn('classroom-first-guide').querySelectorAll('[data-language]').forEach(b=>{b.classList.toggle('active',b.dataset.language===choice);b.onclick=()=>{localStorage.setItem(LESSON_LANGUAGE,b.dataset.language);renderClassroomGuide()}});
  }
  function taskKind(e){const sql=e.solution.trim();if(/^create\s+table\b/i.test(sql))return 'CREATE TABLE';if(/^insert\s+into\b/i.test(sql))return 'INSERT DATA';if(/^update\s+\w+/i.test(sql))return 'UPDATE RECORD';if(/^delete\s+from\b/i.test(sql))return 'DELETE RECORD';if(/^alter\s+table\b/i.test(sql))return 'ALTER TABLE';if(/^drop\s+table\b/i.test(sql))return 'DROP TABLE';if(/^create\s+view\b/i.test(sql))return 'CREATE VIEW';if(/^create\s+index\b/i.test(sql))return 'CREATE INDEX';return 'READ / QUERY DATA'}
  function taskGuide(e){const kind=taskKind(e);const mapping={
     'CREATE TABLE':['Create a new empty table using the table name, columns and data types in the question. Write the complete CREATE TABLE statement yourself.','Question lo ichina table name, columns, data types tho nuvve CREATE TABLE query rayi. Mundu table empty ga untundi.'],
     'INSERT DATA':['The table already exists. Add the requested record by matching column names and values in order.','Table already undi. Adigina record ni INSERT cheyyi. Columns order, values order match avvali.'],
     'UPDATE RECORD':['Change only the requested row. Use a WHERE condition to avoid changing every record.','Adigina row matrame update cheyyi. WHERE lekapothe anni rows change ayye chance undi.'],
     'DELETE RECORD':['Remove only the requested record. Be careful with the WHERE condition.','Adigina row matrame delete cheyyi. WHERE compulsory ani gurthupettuko.'],
     'ALTER TABLE':['The table exists already. Change its columns or structure as asked.','Table already undi. Question lo adigina structure change cheyyi.'],
     'DROP TABLE':['Remove the requested table. Its structure and records will disappear in this temporary practice database.','Adigina table ni remove cheyyi. Practice database next query ki reset avuthundi.'],
     'CREATE VIEW':['Create a named view based on the requested report. Your view will be checked using the database.','Report kosam view ni create cheyyi. Real SQLite verify chesthundi.'],
     'CREATE INDEX':['Create an index for the indicated table/column. It will be checked using the SQLite schema.','Adigina table/column ki index create cheyyi. SQLite schema verify chesthundi.'],
     'READ / QUERY DATA':['Use the sample table below. Find the needed columns, decide the filter / JOIN / calculation, and write your own SELECT query.','Kinda sample table choodu. E columns kavalo, e condition undalo decide chesi nee SELECT query rayi.']};
    return [kind,...(mapping[kind]||mapping['READ / QUERY DATA'])];
  }
  function structureTable(e){
    const found=/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w]+)\s*\(([^)]+)\)/i.exec(e.solution.trim());
    if(!found)return null;
    const fields=found[2].split(',').map(x=>x.trim().split(/\s+/)).filter(x=>x.length>=2);
    return '<div class="schema-board"><div class="schema-top"><span>▤ NEW EMPTY TABLE</span><b>'+escapeHTML(found[1])+'</b></div><p>Column requirements from this question (not a SQL answer). No rows exist yet.</p><table><thead><tr><th>Column name</th><th>Data type</th><th>Required rule</th></tr></thead><tbody>'+fields.map(f=>'<tr><td>'+escapeHTML(f[0])+'</td><td>'+escapeHTML(f[1])+'</td><td>'+escapeHTML(f.slice(2).join(' ')||'—')+'</td></tr>').join('')+'</tbody></table><p class="schema-foot">Think: table name → (column + type + optional constraint) → comma between fields.</p></div>';
  }
  function renderLesson(){
    const t=currentTopic();qfn('breadcrumb-topic').textContent=t.title;qfn('lesson-heading').textContent=t.title;qfn('lesson-subheading').textContent=t.description;qfn('lesson-emoji').textContent=icons[t.id]||'SQL';qfn('lesson-level').textContent=t.level==='medium'?'INTERMEDIATE':t.level.toUpperCase();qfn('lesson-progress').textContent=counts(t)+' / '+t.exercises.length+' passed';
    renderClassroomGuide();
    qfn('concept-description').textContent=t.concept;qfn('concept-steps').textContent=t.steps;qfn('concept-tip').textContent=t.tips;qfn('interview-answer').textContent=t.interview;
    const special=qfn('like-guide');special.hidden=t.id!=='like';
    if(t.id==='like')special.innerHTML=`<h4>LIKE (%) visual memory shortcut</h4><div class="pattern-row"><span>S tho <b>START</b></span><code>LIKE 'S%'</code></div><div class="pattern-row"><span>s tho <b>END</b></span><code>LIKE '%s'</code></div><div class="pattern-row"><span>middle lo phone</span><code>LIKE '%phone%'</code></div><div class="pattern-row"><span>Exactly one character</span><code>LIKE 'S_'</code></div><div class="pattern-row"><span><b>%</b> = 0+ chars, <b>_</b> = 1 char</span><code>'S____'</code></div>`;
    const candidateExamples=C.topicExamples?.[t.id]||C.examples[t.exampleKey]||C.examples.basics;
    const gradedAnswers=new Set(t.exercises.map(e=>E.cleanSql(e.solution).toLowerCase().replace(/\s+/g,' ')));
    const examples=candidateExamples.filter(x=>!gradedAnswers.has(E.cleanSql(x.sql).toLowerCase().replace(/\s+/g,' ')));
    qfn('concept-examples').innerHTML=examples.map((x,i)=>`<div class="example-item"><div class="example-title"><span>${escapeHTML(x.label)}</span><button class="copy-mini" data-copy-example="${i}" title="Copy example syntax">Copy ↗</button></div><pre>${escapeHTML(x.sql)}</pre><p>${escapeHTML(x.note)}</p></div>`).join('');
    qfn('concept-examples').querySelectorAll('[data-copy-example]').forEach(btn=>btn.onclick=()=>copyText(examples[+btn.dataset.copyExample].sql,btn));
  }
  function relatedTables(e){let result=[e.table];for(const name of C.tableNames)if(new RegExp('\\b'+name+'\\b','i').test(e.solution)&&!result.includes(name))result.push(name);return result;}
  function renderTable(name,limit){const data=P[name];if(!data)return '<div class="result-empty">Table not found.</div>';const rows=limit?data.rows.slice(0,5):data.rows;
    return `<table><thead><tr>${data.columns.map(k=>`<th>${escapeHTML(k)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(v=>`<td class="${v===null?'null':''}" title="${escapeHTML(v===null?'NULL':v)}">${v===null?'NULL':escapeHTML(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;}
  function renderDataset(){const e=currentExercise(),tables=relatedTables(e);if(!state.activeTable||!tables.includes(state.activeTable))state.activeTable=e.table;
    const special=structureTable(e);
    qfn('table-expand').hidden=!!special;
    qfn('dataset-tabs').hidden=!!special;
    if(special){qfn('data-table-desc').textContent='Design the table yourself; no sample rows yet';qfn('dataset-table').innerHTML=special;return;}

    qfn('data-table-desc').textContent=C.tableDescriptions[state.activeTable]||'';
    qfn('dataset-tabs').innerHTML=tables.map(name=>`<button class="dataset-tab ${state.activeTable===name?'active':''}" data-table="${name}">${name}</button>`).join('');
    qfn('dataset-tabs').querySelectorAll('[data-table]').forEach(b=>b.onclick=()=>{state.activeTable=b.dataset.table;state.fullTable=false;renderDataset()});
    qfn('dataset-table').innerHTML=renderTable(state.activeTable,!state.fullTable);
    qfn('table-expand').textContent=state.fullTable?'Show fewer rows':'View all rows';
  }
  function updateLineNums(){const txt=qfn('sql-editor').value;const lines=Math.max(4,txt.split('\n').length);qfn('line-nums').innerHTML=Array.from({length:lines},(_,i)=>i+1).join('<br>');}
  function renderExercise(){const t=currentTopic(),e=currentExercise();const p=String(state.exercise+1).padStart(2,'0');const total=String(t.exercises.length).padStart(2,'0');
    qfn('question-prompt').textContent=e.prompt;qfn('challenge-number').textContent=`CHALLENGE ${p} / ${total}`;
    const [kind,en,tg]=taskGuide(e);qfn('task-kind').textContent=kind;qfn('task-english').textContent='Simple English: '+en;qfn('task-tenglish').textContent='Tenglish: '+tg;
    qfn('practice-instructions').textContent=kind==='CREATE TABLE'?'First design your table. No sample rows are needed until you INSERT data.':'Write SQL yourself → run it → review actual output and hints.';
    qfn('resume-description').textContent=`${t.level==='medium'?'INTERMEDIATE':t.level.toUpperCase()} → ${t.title} → Question ${state.exercise+1}/${t.exercises.length}. Continue exactly here.`;qfn('challenge-difficulty').textContent='● '+(t.level==='medium'?'Intermediate':t.level[0].toUpperCase()+t.level.slice(1));
    qfn('exercise-dots').innerHTML=t.exercises.map((v,i)=>`<span class="${state.passed[v.id]?'solved':i===state.exercise?'active':''}" title="Question ${i+1}${state.passed[v.id]?' passed':''}"></span>`).join('');
    qfn('prev-btn').disabled=state.exercise===0&&topics.filter(x=>x.level===state.level)[0].id===t.id;
    qfn('next-btn').disabled=state.exercise===t.exercises.length-1&&topics.filter(x=>x.level===state.level).at(-1).id===t.id;
    qfn('sql-editor').value=state.drafts[e.id]||'';
    qfn('sql-editor').placeholder=kind==='CREATE TABLE'?'-- Create an empty table yourself\n-- Think: table name, columns, data types\n-- Write your SQL below...':kind==='INSERT DATA'?'-- This table already exists\n-- Decide which columns and values to add\n-- Write your INSERT statement...':kind==='UPDATE RECORD'?'-- Which row should change?\n-- Which column gets a new value?':kind==='DELETE RECORD'?'-- Which record must be removed?\n-- Consider a safe WHERE condition':kind==='READ / QUERY DATA'?'-- See the sample table above\n-- Choose needed columns and conditions\n-- Write your own SELECT query...':'-- Read the task above\n-- Write your SQL statement here...';
    updateLineNums();
    renderDataset();qfn('result-area').innerHTML='';qfn('complete-next-btn').hidden=true;qfn('hint-area').hidden=!state.hint;if(state.hint)qfn('hint-area').innerHTML='<strong>HINT</strong> · '+escapeHTML(e.hint);
    qfn('hint-btn').textContent=state.hint?'✧ Hide hint':'✧ Show hint';
    qfn('check-btn').disabled=state.checking;
  }
  function renderAll(){renderNav();renderLesson();renderExercise();}
  function resultTable(data){if(!data)return '<div class="result-empty">Your query could not execute, so no output is available.</div>';
    if(!data.rows.length)return `<div class="result-empty">No rows returned (0 matches).</div>`;
    return `<div class="table-wrap result-table"><table><thead><tr>${data.columns.map(x=>`<th>${escapeHTML(x)}</th>`).join('')}</tr></thead><tbody>${data.rows.map(row=>`<tr>${row.map(v=>`<td class="${v===null?'null':''}">${v===null?'NULL':escapeHTML(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${data.totalRows>data.rows.length?`<p class="small-muted">First ${data.rows.length} of ${data.totalRows} results shown.</p>`:''}`;
  }
  function showResult(data){const success=data.ok;const e=currentExercise();
    const why=data.explanation||e.why;
    const feedback=data.message||'';
    const steps=!success?`<div class="guided-repair"><div class="feedback-label">✦ LEARN, DON'T COPY</div><p><b>Step 1 — Mistake:</b> ${escapeHTML(feedback)}</p><p><b>Step 2 — Concept:</b> ${escapeHTML(why)}</p><p><b>Step 3 — Your next attempt:</b> ${escapeHTML(e.hint||'Think about the requested columns and filtering / grouping rule.')}</p><button class="repair-coach" id="ask-fix-tutor">✦ Ask AI Coach for another hint (no answer)</button></div>`:`<div class="feedback-label">WHY YOUR QUERY WORKS</div><p class="explain-feedback">${escapeHTML(why)}</p>`;
    qfn('result-area').innerHTML=`<div class="result-card ${success?'success':'error'}"><div class="result-heading"><div class="result-icon">${success?'✓':'⚠'}</div><div><h4>${escapeHTML(data.headline||'Query feedback')}</h4><p>${escapeHTML(feedback)}</p></div></div><div class="result-body"><div class="result-subtitle"><span>${e.mode==='mutation'?'YOUR CHANGED TABLE / SCHEMA':'YOUR QUERY OUTPUT'}</span><small>${data.queryOutput?.totalRows??0} rows</small></div>${resultTable(data.queryOutput)}${!success?`<div class="result-subtitle"><span>EXPECTED OUTPUT (TARGET)</span><small>${data.expectedOutput?.totalRows??0} rows</small></div>${resultTable(data.expectedOutput)}`:''}${steps}${data.ok?'<p class="explain-feedback" style="color:var(--good)">✓ Challenge completed! Next question lo different conditions and sample data try cheyyi.</p>':''}</div></div>`;
    if(!success&&qfn('ask-fix-tutor'))qfn('ask-fix-tutor').onclick=()=>window.SQLLAB_TUTOR?.open('Na present query lo mistake ento concept, one hint tho explain cheyyi. Full answer ivvaku.');
    qfn('complete-next-btn').hidden=!success;
    qfn('result-area').scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  async function checkQuery(){if(state.checking)return;const e=currentExercise();const sql=qfn('sql-editor').value;
    state.drafts[e.id]=sql;state.attempts[e.id]=(state.attempts[e.id]||0)+1;stored();
    if(state.engine==='unavailable'){showResult({ok:false,headline:'SQLite engine not available',message:'Internet on cheyyi (browser WASM download kosam), leda Node.js server tho run cheyyi. README choodu.',explanation:e.why});return;}
    state.checking=true;qfn('check-btn').disabled=true;qfn('check-btn').innerHTML='⏳ Running SQLite...';
    try{
      let result;
      if(state.engine==='server'){
        let response=await fetch('/api/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({exerciseId:e.id,sql})});
        result=await response.json();if(!response.ok)throw Error(result.message||'Server error');
      }else{
        if(!window.__sqlJs)throw Error('SQLite WASM is not initialized');
        result=E.runAssessment(e,sql,createBrowserSession);
      }
      state.result=result;
      if(result.ok){state.passed[e.id]=true;stored();renderNav();qfn('lesson-progress').textContent=counts(currentTopic())+' / '+currentTopic().exercises.length+' passed';qfn('exercise-dots').children[state.exercise].className='solved';}
      showResult(result);
    }catch(err){console.error(err);showResult({ok:false,headline:'Could not check your query',message:String(err.message||err),explanation:'Connection refresh chesi retry cheyyi.'});}
    finally{state.checking=false;qfn('check-btn').disabled=false;qfn('check-btn').innerHTML='<span>▶</span> Run & Check Query';}
  }
  function createBrowserSession(){const db=new window.__sqlJs.Database();db.exec(C.seed);return {
    execute(sql){db.run(sql)},read(sql){const results=db.exec(sql);if(!results.length){return {columns:[],rows:[]}}return {columns:results[0].columns,rows:results[0].values};},close(){db.close()}
  };}
  function copyText(txt,button){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(txt).then(()=>{if(button){const old=button.textContent;button.textContent='Copied ✓';setTimeout(()=>button.textContent=old,1400)}}).catch(()=>fallbackCopy(txt));}else fallbackCopy(txt);}
  function fallbackCopy(txt){const ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();try{document.execCommand('copy')}catch(_e){}ta.remove()}
  function badge(label,mode){const el=qfn('engine-badge');el.className='engine-badge '+mode;el.innerHTML='<span class="state-dot"></span>'+escapeHTML(label)}
  async function loadRemoteJS(src){return new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=src;script.onload=resolve;script.onerror=()=>reject(new Error('Could not load '+src));document.head.appendChild(script);});}
  async function initializeEngine(){
    if(location.protocol==='http:'||location.protocol==='https:'){
      try{const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),1700);const res=await fetch('/api/health',{signal:ctrl.signal});clearTimeout(timer);if(res.ok){const data=await res.json();if(data.ok){state.engine='server';badge('Real SQLite · Local server','live');window.SQLLAB_AI_ENABLED=!!data.aiEnabled;return;}}}catch(_err){}
    }
    badge('Loading browser SQLite...','');
    const hosts=['https://cdn.jsdelivr.net/npm/sql.js@1.12.0/dist/','https://unpkg.com/sql.js@1.12.0/dist/'];
    for(const base of hosts){
      try{
        if(!window.initSqlJs)await loadRemoteJS(base+'sql-wasm.js');
        window.__sqlJs=await window.initSqlJs({locateFile:file=>base+file});
        const test=createBrowserSession();const result=test.read('SELECT COUNT(*) AS n FROM products');test.close();if(result.rows[0][0]!==15)throw Error('SQLite smoke test failed');
        state.engine='browser';badge('Real SQLite · Browser','live');return;
      }catch(err){console.warn('SQLite CDN unavailable',base,err)}
    }
    state.engine='unavailable';badge('SQLite offline · See README','offline');
  }
  function bind(){
    qfn('theme-toggle').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';localStorage.setItem(THEME,state.theme);setTheme()};
    qfn('open-sidebar').onclick=()=>{qfn('sidebar').classList.add('open');qfn('sidebar-shade').classList.add('open')};qfn('close-sidebar').onclick=closeMenu;qfn('sidebar-shade').onclick=closeMenu;
    qfn('prev-btn').onclick=()=>changeExercise(state.exercise-1);qfn('next-btn').onclick=()=>changeExercise(state.exercise+1);qfn('skip-btn').onclick=()=>changeExercise(state.exercise+1);qfn('complete-next-btn').onclick=()=>changeExercise(state.exercise+1);
    qfn('check-btn').onclick=checkQuery;qfn('table-expand').onclick=()=>{state.fullTable=!state.fullTable;renderDataset()};
    qfn('hint-btn').onclick=()=>{state.hint=!state.hint;qfn('hint-area').hidden=!state.hint;qfn('hint-area').innerHTML='<strong>HINT</strong> · '+escapeHTML(currentExercise().hint);qfn('hint-btn').textContent=state.hint?'✧ Hide hint':'✧ Show hint'};
    qfn('clear-btn').onclick=()=>{qfn('sql-editor').value='';state.drafts[currentExercise().id]='';state.result=null;stored();qfn('result-area').innerHTML='';qfn('complete-next-btn').hidden=true;updateLineNums();qfn('sql-editor').focus()};
    qfn('sql-editor').oninput=()=>{state.drafts[currentExercise().id]=qfn('sql-editor').value;stored();updateLineNums()};
    qfn('sql-editor').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();checkQuery();}if(e.key==='Tab'){e.preventDefault();const el=e.target,sel=el.selectionStart;el.value=el.value.slice(0,sel)+'  '+el.value.slice(el.selectionEnd);el.selectionStart=el.selectionEnd=sel+2;el.dispatchEvent(new Event('input'));}};
  }
  window.SQLLAB_GET_CONTEXT=()=>({mode:'guided',topic:currentTopic().title,level:state.level,prompt:currentExercise().prompt,learnerSql:qfn('sql-editor').value,feedback:state.result?.message||'',sampleTables:(relatedTables(currentExercise()).map(name=>name+': '+P[name]?.columns.join(', ')).join(' | '))});
  setTheme();bind();renderAll();setupBackup();stored();document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')stored()});initializeEngine();
})();
