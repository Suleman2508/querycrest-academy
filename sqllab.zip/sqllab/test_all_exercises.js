const C=require('./content.js');
const E=require('./engine.js');
const {DatabaseSync}=require('node:sqlite');
const createSession=()=>{const db=new DatabaseSync(':memory:');db.exec(C.seed);return {execute(sql){db.exec(sql)},read(sql){const stmt=db.prepare(sql);const columns=stmt.columns().map(c=>c.name);const rows=stmt.all().map(r=>columns.map(c=>r[c]));return {columns,rows}},close(){db.close()}}};
let passed=0,failed=[];
for(const topic of C.topics){for(const e of topic.exercises){let result;try{result=E.runAssessment(e,e.solution,createSession)}catch(err){failed.push([e.id,String(err)]);continue}if(result.ok)passed++;else failed.push([e.id,result.headline,result.message])}}
const e=E.exerciseById('b-where-1');
const boundary=E.runAssessment(e,'SELECT name, price FROM products WHERE price >= 50000;',createSession);
console.log(JSON.stringify({total:C.topics.reduce((n,t)=>n+t.exercises.length,0),passed,failed:failed.slice(0,30),boundaryWrongRejected:!boundary.ok,boundaryTitle:boundary.headline},null,2));
if(failed.length||boundary.ok)process.exitCode=1;
