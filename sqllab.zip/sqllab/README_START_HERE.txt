SQLLAB v17.5 — Transparent Blooming Classroom

Fixed: Learning Path visibility at desktop widths and after a previous Focus Mode session.
On mobile, tap the menu / Learning Path control.
Step 1 and Step 2 use transparent glass panels; blooming tree is larger across the page.
The same 34 topics and 119 challenges, real SQL checker, notes, autosave, backup/restore.

VS CODE / NODE:
  node server.js
  http://localhost:3032

Existing port 3032 progress should remain in the same browser; make a backup as a precaution.

NETLIFY:
  Deploy the extracted folder with index.html at root; server.js is ignored in static hosting.
  Browser-based SQLite may load an online runtime; no API key is needed.

SINGLE HTML:
  Open SQLLAB_Open_In_Chrome.html in Chrome (offline SQLite runtime availability may vary).

IMPORTANT:
  Public URL alone does not provide per-user cloud accounts, cross-device sync or isolation.
