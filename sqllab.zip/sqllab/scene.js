/* SQLLAB home controller — no animation, no network, no fake cloud login. */
(()=>{'use strict';
 const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
 const K='sqllab-progress-v2',LAST='sqllab-v7-lastview',GOAL='sqllab-v7-goal-';
 const content=window.SQL_HUB_CONTENT||{},topics=content.topics||[],levelNames={basic:'Basic',medium:'Intermediate',advanced:'Advanced'};
 const safeGet=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch{return d}};
 const getProgress=()=>safeGet(K,{passed:{},position:{}});
 const questionTotal=topics.reduce((n,t)=>n+t.exercises.length,0);
 const activeTopic=()=>{const p=getProgress().position||{};return topics.find(t=>t.id===p.topic)||topics[0]};
 function update(){const p=getProgress(),passed=p.passed||{},done=Object.values(passed).filter(Boolean).length,overall=questionTotal?Math.round(done*100/questionTotal):0;
   const completed=topics.filter(t=>t.exercises.every(e=>passed[e.id])).length;
   const put=(id,v)=>{const el=$('#'+id);if(el)el.textContent=v};const wd=(id,v)=>{const el=$('#'+id);if(el)el.style.width=v+'%'};
   put('sc-topics-done',completed);put('sc-queries-done',done);put('sc-pct',overall+'%');put('sc-remaining',questionTotal-done);put('sc-ring-label',overall+'%');put('sc-count-label',done+' / '+questionTotal+' Questions');
   $('#sc-ring').style.background=`conic-gradient(var(--v17-blue) ${overall*3.6}deg,var(--v17-border) ${overall*3.6}deg)`;
   ['basic','medium','advanced'].forEach(l=>{const es=topics.filter(t=>t.level===l).flatMap(t=>t.exercises),doneL=es.filter(e=>passed[e.id]).length,n=es.length,pc=n?Math.round(doneL*100/n):0;const slug=l==='medium'?'medium':l;put('sc-'+slug+'-pct',pc+'%');put('sc-'+slug+'-count',pc+'%');wd('sc-'+slug+'-bar',pc);wd('sc-'+slug+'-rail',pc)});
   const t=activeTopic();if(t){put('sc-last-title',t.title);put('sc-last-desc',`${levelNames[t.level]||'SQL'} SQL · ${t.exercises.filter(e=>passed[e.id]).length} / ${t.exercises.length} questions complete`);wd('sc-last-bar',Math.round(t.exercises.filter(e=>passed[e.id]).length*100/t.exercises.length))}
 }
 function setHome(on){document.body.classList.toggle('home-mode',on);try{localStorage.setItem(LAST,on?'home':'lesson')}catch{};$$('.scene-topnav button').forEach(b=>b.classList.toggle('current',b.dataset.go===(on?'home':'learn')));window.scrollTo(0,0);if(on)update();}
 function selectTopic(id){setHome(false);const btn=$$('.topic-link').find(b=>b.dataset.id===id||b.dataset.topic===id);if(btn){btn.click();return true}const t=topics.find(t=>t.id===id);if(!t)return false;const lv=['basic','medium','advanced'].indexOf(t.level);if(lv>=0){const levelButtons=$$('.nav-level');levelButtons[lv]?.click();const next=$$('.topic-link').find(b=>b.dataset.id===id||b.dataset.topic===id||b.textContent.toLowerCase().includes(t.title.toLowerCase()));next?.click()}return true}
 function selectLevel(level){setHome(false);const lv=['basic','medium','advanced'].indexOf(level);$$('.nav-level')[lv]?.click();document.querySelector('.lesson-bar')?.scrollIntoView({block:'start'})}
 function go(action){switch(action){case'home':setHome(true);break;case'progress':setHome(true);setTimeout(()=>$('.rail-panel')?.scrollIntoView({block:'nearest',behavior:'instant'}),0);break;case'learn':setHome(false);$('.lesson-bar')?.scrollIntoView({block:'start'});break;case'roadmap':setHome(false);const overview=$('#v15-curriculum');if(overview)overview.open=true;overview?.scrollIntoView({block:'start'});break;case'practice':setHome(false);window.SQLLAB_LAB?.setMode('guided');$('.lesson-bar')?.scrollIntoView({block:'start'});break;case'interview':setHome(false);window.SQLLAB_LAB?.setMode('guided');const extra=$('#existing-lesson-reference');if(extra)extra.open=true;$('.interview-card')?.scrollIntoView({block:'center'});break;case'projects':setHome(false);window.SQLLAB_LAB?.setMode('custom');$('.workspace-switch')?.scrollIntoView({block:'start'});break;case'backup':setHome(false);$('.resume-panel')?.scrollIntoView({block:'center'});break}}
 $$('[data-go]').forEach(btn=>btn.addEventListener('click',()=>go(btn.dataset.go)));
 $$('[data-level]').forEach(btn=>btn.addEventListener('click',()=>selectLevel(btn.dataset.level)));
 $$('[data-topic]').forEach(btn=>btn.addEventListener('click',()=>selectTopic(btn.dataset.topic)));
 $('#scene-continue').addEventListener('click',()=>go('practice'));
 const search=$('#scene-search'),results=$('#scene-search-results');
 function matches(){let value=search.value.toLowerCase().trim();if(!value){results.hidden=true;results.replaceChildren();return []}let list=topics.filter(t=>[t.title,t.id,t.level].some(s=>String(s).toLowerCase().includes(value))).slice(0,9);results.replaceChildren();if(!list.length){let p=document.createElement('p');p.textContent='No matching topic found.';p.style.padding='9px 13px';results.append(p)}else list.forEach(t=>{let b=document.createElement('button');b.type='button';b.setAttribute('role','option');b.textContent=t.title;let sm=document.createElement('small');sm.textContent=(levelNames[t.level]||t.level)+' SQL · '+t.exercises.length+' practice questions';b.append(sm);b.addEventListener('click',()=>{search.value='';results.hidden=true;selectTopic(t.id)});results.append(b)});results.hidden=false;return list}
 search.addEventListener('input',matches);search.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const list=matches();if(list.length){search.value='';results.hidden=true;selectTopic(list[0].id)}}if(e.key==='Escape')results.hidden=true});document.addEventListener('click',e=>{if(!e.target.closest('.scene-search-wrap'))results.hidden=true});
 const today=new Date().toLocaleDateString('en-CA');['read','solve','review'].forEach(k=>{const el=$('#goal-'+k),key=GOAL+today+'-'+k;el.checked=localStorage.getItem(key)==='yes';el.addEventListener('change',()=>localStorage.setItem(key,el.checked?'yes':'no'))});
 const mode=localStorage.getItem(LAST)||'home';setHome(mode!=='lesson');
 // Keep dashboard counts current when returning from lesson; learning progress is saved by original app.js
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)update()});window.addEventListener('storage',update);
 update();
})();
