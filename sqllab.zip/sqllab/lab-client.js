/* Browser custom dataset creation, local persistence, SQL query execution. */
(()=>{'use strict';
 const KEY='sqllab-own-tables-v1',DRAFT='sqllab-own-query-v1';
 const $=id=>document.getElementById(id);
 const enc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const presets={
  students:{name:'my_students',columns:'id INTEGER\nname TEXT\nmarks INTEGER\ncity TEXT',rows:'1,Swathi,92,Bangalore\n2,Ravi,67,Hyderabad\n3,Suman,85,Chennai\n4,Satish,58,Anantapur\n5,Sana,96,Hyderabad'},
  employees:{name:'my_employees',columns:'id INTEGER\nname TEXT\ndepartment TEXT\nsalary INTEGER',rows:'1,Asha,IT,70000\n2,Ravi,Sales,45000\n3,Meera,IT,62000\n4,Salman,Support,35000\n5,Anu,Sales,54000'},
  inventory:{name:'my_inventory',columns:'id INTEGER\nproduct TEXT\ncategory TEXT\nprice REAL\nstock INTEGER',rows:'1,Mouse,Accessories,750,12\n2,Samsung Phone,Electronics,26000,7\n3,Laptop,Electronics,58000,5\n4,Shoes,Fashion,2400,19\n5,Sofa,Home,18000,3'},
  blank:{name:'',columns:'id INTEGER\nname TEXT\nvalue INTEGER',rows:''}
 };
 const state={mode:localStorage.getItem('sqllab-workspace-v1')==='custom'?'custom':'guided',tables:[],selected:null,aiQuestions:[]};
 try{let t=JSON.parse(localStorage.getItem(KEY)||'[]');if(Array.isArray(t))state.tables=t.slice(0,8)}catch{}
 const identifier=s=>/^[A-Za-z_][A-Za-z_0-9]{0,39}$/.test(s);
 function csvRow(line){let fields=[],current='',quoted=false;
 for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(quoted&&line[i+1]==='"'){current+='"';i++;}else quoted=!quoted;}
 else if(c===','&&!quoted){fields.push(current.trim());current='';}else current+=c;}
 if(quoted)throw Error('CSV quote incomplete; use double quotes around fields with commas.');fields.push(current.trim());return fields;
 }
 function parseForm(){const name=$('lab-name').value.trim();if(!identifier(name))throw Error('Table name letters, numbers or underscores tho start / continue avvali.');
 const columns=$('lab-columns').value.trim().split(/\n+/).filter(Boolean).map(line=>{const m=line.trim().match(/^([a-zA-Z_][a-zA-Z_0-9]{0,39})\s+(INTEGER|TEXT|REAL|NUMERIC)$/i);if(!m)throw Error('Column line format: name TYPE (e.g. marks INTEGER)');return {name:m[1],type:m[2].toUpperCase()};});
 if(columns.length<1||columns.length>15||new Set(columns.map(x=>x.name.toLowerCase())).size!==columns.length)throw Error('Use 1–15 unique columns.');
 const rows=$('lab-rows').value.trim()?$('lab-rows').value.trim().split('\n').filter(Boolean).map(csvRow):[];
 if(rows.length>120)throw Error('120 sample records maximum');
 for(let i=0;i<rows.length;i++){if(rows[i].length!==columns.length)throw Error('Row '+(i+1)+' has '+rows[i].length+' values. Expected '+columns.length+'.');}
 return {name,columns,rows};
 }
 function showMessage(msg,success=false){$('lab-create-msg').textContent=msg;$('lab-create-msg').classList.toggle('ok',success)}
 function save(){try{localStorage.setItem(KEY,JSON.stringify(state.tables));}catch{showMessage('Browser storage full. Fewer rows try cheyyi.')}}
 function loadPreset(name){const p=presets[name];if(!p)return;$('lab-name').value=p.name;$('lab-columns').value=p.columns;$('lab-rows').value=p.rows;showMessage('Sample form loaded. Create / Replace Table click cheyyi.');}
 function render(){const tables=state.tables;
 if(!tables.find(t=>t.name===state.selected))state.selected=tables[0]?.name||null;
 $('lab-table-count').textContent=`(${tables.length}/8)`;
 $('lab-tables').innerHTML=tables.length?tables.map(t=>`<div class="lab-table-item"><button class="lab-table-open ${state.selected===t.name?'selected':''}" data-open="${enc(t.name)}">▦ <b>${enc(t.name)}</b><small>${t.rows.length} rows</small></button><button class="lab-table-delete" aria-label="Delete ${enc(t.name)}" title="Delete table" data-remove="${enc(t.name)}">×</button></div>`).join(''):'<p class="small-muted">No tables created. Load a sample or build one above.</p>';
 $('lab-active-tables').innerHTML=tables.map(t=>`<button class="dataset-tab ${state.selected===t.name?'active':''}" data-view="${enc(t.name)}">${enc(t.name)}</button>`).join('');
 const t=tables.find(x=>x.name===state.selected);
 $('lab-preview').innerHTML=t?`<table><thead><tr>${t.columns.map(c=>`<th>${enc(c.name)}<small> ${enc(c.type)}</small></th>`).join('')}</tr></thead><tbody>${t.rows.slice(0,25).map(r=>`<tr>${r.map(v=>`<td>${enc(v===''?'NULL':v)}</td>`).join('')}</tr>`).join('')}</tbody></table>${t.rows.length>25?`<p class="small-muted">First 25 rows of ${t.rows.length}</p>`:''}`:'<div class="result-empty">Create your first table to preview the records.</div>';
 const suggestions=t?(state.aiQuestions.length?state.aiQuestions.map((q,i)=>`<span>${i+1}. ${enc(q)}</span>`).join(''):`<span>1. ${enc(t.name)} lo all rows list cheyyi</span><span>2. First 3 columns matrame select cheyyi</span><span>3. Oka column meeda WHERE condition try cheyyi</span><span>4. COUNT(*) use chesi total rows find cheyyi</span>`):'<span>Build a table to unlock guided practice ideas.</span>';
 $('lab-suggested-challenges').innerHTML=suggestions;
 document.querySelectorAll('[data-open],[data-view]').forEach(b=>b.onclick=()=>{state.selected=b.dataset.open||b.dataset.view;render()});
 document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{const name=b.dataset.remove;if(!confirm('Delete custom table '+name+'?'))return;state.tables=state.tables.filter(t=>t.name!==name);save();render();showMessage('Deleted '+name+'.',true)});
 }
 function tableResult(d){if(!d.rows.length)return '<div class="result-empty">Query ran successfully; 0 matching rows.</div>';
 return `<div class="table-wrap result-table"><table><thead><tr>${d.columns.map(c=>`<th>${enc(c)}</th>`).join('')}</tr></thead><tbody>${d.rows.map(row=>`<tr>${row.map(v=>`<td>${v===null?'NULL':enc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
 }
 function showResult(d){$('lab-result').innerHTML=d.ok?`<div class="result-card success"><div class="result-heading"><div class="result-icon">✓</div><div><h4>Query executed successfully</h4><p>Actual SQLite output · ${d.totalRows} rows returned</p></div></div><div class="result-body">${tableResult(d)}<p class="lab-help">Custom queries ki fixed correct answer ledu. Output compare chesi logical correctness check cheyyi; AI Coach nundi hint adagochu.</p></div></div>`:`<div class="result-card error"><div class="result-heading"><div class="result-icon">⚠</div><div><h4>Query needs correction</h4><p>${enc(d.message||'Check SQL syntax.')}</p></div></div><div class="result-body"><button class="repair-coach" id="lab-fix">✦ Help me understand this mistake</button></div></div>`;
 if($('lab-fix'))$('lab-fix').onclick=()=>window.SQLLAB_TUTOR?.open('Na own table query lo error vachindi. Error explain chesi one hint ivvu, final SQL answer ivvaku.');
 }
 function validation(sql){const cleaned=sql.trim().replace(/;+\s*$/,'');if(!/^(SELECT|WITH|EXPLAIN)\b/i.test(cleaned))throw Error('SELECT, WITH, or EXPLAIN queries only. Use table builder for creating tables.');if(cleaned.length>3500)throw Error('Query too long');const safe=cleaned.replace(/'(?:''|[^'])*'|"(?:""|[^"])*"|--[^\n]*/g,'TEXT');if(/;|\b(ATTACH|DETACH|PRAGMA|VACUUM|CREATE|DROP|UPDATE|DELETE|INSERT|ALTER|REPLACE)\b/i.test(safe))throw Error('One read-only statement at a time');return cleaned;}
 async function browserRun(sql){const d=new window.__sqlJs.Database();try{for(const t of state.tables){d.run(`CREATE TABLE "${t.name}" (${t.columns.map(c=>'"'+c.name+'" '+c.type).join(',')})`);const stmt=d.prepare(`INSERT INTO "${t.name}" VALUES (${t.columns.map(()=>'?').join(',')})`);for(const row of t.rows)stmt.run(row.map((v,i)=>v===''?null:t.columns[i].type==='TEXT'?v:Number(v)));stmt.free()}
 const r=d.exec(validation(sql));return {ok:true,columns:r[0]?.columns||[],rows:(r[0]?.values||[]).slice(0,150),totalRows:r[0]?.values?.length||0};}finally{d.close()}}
 async function execute(){if(!state.tables.length)return showResult({ok:false,message:'Create a table first.'});const sql=$('lab-sql').value;
 $('lab-run').disabled=true;$('lab-run').textContent='Running...';
 try{let result;if(window.SQLLAB_AI_ENABLED!==undefined&&window.SQLLAB_AI_ENABLED!==null){const r=await fetch('/api/playground',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tables:state.tables,sql})});result=await r.json();if(!r.ok)throw Error(result.message||'Server error');}
 else if(window.__sqlJs)result=await browserRun(sql);
 else{try{const r=await fetch('/api/playground',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tables:state.tables,sql})});if(!r.ok)throw Error('Server disconnected');result=await r.json();}catch{throw Error('SQLite not available. Use node server.js or connect to the internet for browser SQLite.')}}
 showResult(result);
 }catch(err){showResult({ok:false,message:err.message})}finally{$('lab-run').disabled=false;$('lab-run').textContent='▶ Run My Query'}
 }
 function setMode(mode){state.mode=mode;try{localStorage.setItem('sqllab-workspace-v1',mode)}catch{}
 $('guided-workspace').hidden=mode!=='guided';$('custom-workspace').hidden=mode!=='custom';
 $('guided-tab').classList.toggle('active',mode==='guided');$('custom-tab').classList.toggle('active',mode==='custom');
 $('guided-tab').setAttribute('aria-selected',String(mode==='guided'));$('custom-tab').setAttribute('aria-selected',String(mode==='custom'));
 $('custom-tab').scrollIntoView({behavior:'smooth',block:'nearest'});render();
 }
 function getContext(){return {mode:'custom',topic:'User-defined custom tables',level:'self-paced',prompt:'Learner is practicing independently on own tables. Explain concepts and hints only; do not provide a completed answer.',learnerSql:$('lab-sql').value,feedback:$('lab-result').textContent.slice(0,600),sampleTables:state.tables.map(t=>t.name+' ('+t.columns.map(c=>c.name+' '+c.type).join(', ')+') sample rows: '+JSON.stringify(t.rows.slice(0,4))).join(' | ').slice(0,2200)};}
 $('guided-tab').onclick=()=>setMode('guided');$('custom-tab').onclick=()=>setMode('custom');
 $('lab-load-preset').onclick=()=>{state.aiQuestions=[];loadPreset($('lab-preset').value)};
 const freeSamples={
  movies:{name:'my_movies',columns:[['id','INTEGER'],['title','TEXT'],['genre','TEXT'],['rating','REAL']],rows:[[1,'Sky Road','Drama',8.1],[2,'City Lights','Comedy',7.4],[3,'Blue Ocean','Action',6.9],[4,'Summer Sun','Drama',9.0]]},
  payments:{name:'my_payments',columns:[['id','INTEGER'],['method','TEXT'],['amount','REAL'],['status','TEXT']],rows:[[1,'UPI',1200,'Success'],[2,'Card',2500,'Failed'],[3,'UPI',800,'Success'],[4,'Cash',600,'Pending']]},
  cricket:{name:'my_cricket',columns:[['id','INTEGER'],['player','TEXT'],['team','TEXT'],['runs','INTEGER']],rows:[[1,'Arjun','Blue',74],[2,'Rahul','Red',46],[3,'Sana','Blue',91],[4,'Kiran','Red',35]]},
  students:{name:'my_students',columns:[['id','INTEGER'],['name','TEXT'],['city','TEXT'],['marks','INTEGER']],rows:[[1,'Sana','Hyderabad',84],[2,'Ravi','Anantapur',72],[3,'Simran','Bengaluru',92],[4,'Manu','Hyderabad',67]]},
  employees:{name:'my_employees',columns:[['id','INTEGER'],['name','TEXT'],['department','TEXT'],['salary','INTEGER']],rows:[[1,'Asha','IT',58000],[2,'Raj','Sales',42000],[3,'Sita','IT',65000],[4,'Hari','HR',40000]]},
  shop:{name:'my_shop',columns:[['id','INTEGER'],['product','TEXT'],['category','TEXT'],['price','REAL']],rows:[[1,'Shirt','Clothes',750],[2,'Mouse','Tech',599],[3,'Saree','Clothes',1450],[4,'Keyboard','Tech',1099]]},
  books:{name:'my_books',columns:[['id','INTEGER'],['title','TEXT'],['author','TEXT'],['price','REAL']],rows:[[1,'Ocean','Sana',320],[2,'Sky','Ravi',450],[3,'History','Sana',210],[4,'Design','Anu',580]]},
  cars:{name:'my_cars',columns:[['id','INTEGER'],['brand','TEXT'],['model','TEXT'],['price','INTEGER']],rows:[[1,'Tata','Punch',700000],[2,'Maruti','Swift',690000],[3,'Hyundai','i20',870000],[4,'Tata','Nexon',1050000]]}
 };
 function freeTable(topic){const q=topic.toLowerCase();let k=/movie|film/.test(q)?'movies':/pay|transaction|fintech/.test(q)?'payments':/cricket|sport|player/.test(q)?'cricket':/student|college|exam|mark/.test(q)?'students':/employee|office|staff|salary/.test(q)?'employees':/shop|store|product|stock|inventory/.test(q)?'shop':/book|library/.test(q)?'books':/car|vehicle/.test(q)?'cars':'shop';return freeSamples[k]}
 $('lab-generate').onclick=()=>{const topic=$('lab-topic').value.trim();if(!topic)return showMessage('Table topic type cheyyi (movies, payments, cricket, students, employees, books, cars, shop).');
 const tab=freeTable(topic);$('lab-name').value=tab.name;$('lab-columns').value=tab.columns.map(c=>c.join(' ')).join('\n');$('lab-rows').value=tab.rows.map(r=>r.join(',')).join('\n');
 state.aiQuestions=[`Show some records from ${tab.name} using a WHERE filter`,`Find total number of records in ${tab.name}`,`Find a grouped or sorted report for ${tab.name}`];showMessage('✓ Free sample ready. Create / Replace Table click cheyyi. Built-in samples matrame; no API required.',true);
 };
 $('lab-create').onclick=()=>{try{const t=parseForm();const index=state.tables.findIndex(x=>x.name.toLowerCase()===t.name.toLowerCase());if(index===-1&&state.tables.length===8)throw Error('Maximum 8 tables; delete one first');if(index===-1)state.tables.push(t);else state.tables[index]=t;state.selected=t.name;save();render();showMessage('✓ '+t.name+' created with '+t.rows.length+' records. Now practice your query!',true)}catch(err){showMessage('⚠ '+err.message)}};
 $('lab-run').onclick=execute;$('lab-clear').onclick=()=>{$('lab-sql').value='';$('lab-result').innerHTML='';localStorage.removeItem(DRAFT);updateLines()};
 $('lab-ask').onclick=()=>window.SQLLAB_TUTOR?.open('Na own table query lo question undi. Context chusi one guiding hint ivvu; full SQL query rayaku.');
 const updateLines=()=>{$('lab-line-nums').innerHTML=Array.from({length:Math.max(4,$('lab-sql').value.split('\n').length)},(_,i)=>i+1).join('<br>')};
 $('lab-sql').value=localStorage.getItem(DRAFT)||'';$('lab-sql').oninput=()=>{localStorage.setItem(DRAFT,$('lab-sql').value);updateLines()};
 $('lab-sql').onkeydown=e=>{if(e.key==='Enter'&&(e.metaKey||e.ctrlKey)){e.preventDefault();execute()}};
 loadPreset('students');render();updateLines();if(state.mode==='custom')setMode('custom');
 window.SQLLAB_LAB={getContext,isCustom:()=>state.mode==='custom',setMode};
})();
